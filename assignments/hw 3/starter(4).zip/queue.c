#include <stdio.h>
#include "queue.h"

void initQueue(Queue* q)
{
  /* TODO: Allocate memory and initialize the stacks of the queue. */
}

void enQueue(Queue* q, int number)
{
  /* TODO: Fill this in, one line of code */
}

int deQueue(Queue* q)
{
  /*
    TODO: Check if stack 2 is empty. If it is, flip all of the elements from stack 1 to stack 2. Then, pop and return the element from stack 2.
   */
}

void freeQueue(Queue* q)
{
  /* TODO: Free up all the allocated memory. */
}
