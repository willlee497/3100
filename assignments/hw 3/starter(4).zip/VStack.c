/* NOTE: To test this program, you must create a copy of vector.c and vector.h that you've implemented in 1.2 */

#include "VStack.h"

void initStack(Stack * s)
{
  /* TODO: Fill this in. One line of code. */
}

void pushStack(Stack* stack, int number)
{
  /* TODO: Fill this in. One line of code. */
}

int popStack(Stack* stack)
{
  /* TODO: Fill this in. One line of code. */
}

void freeStack(Stack* stack)
{
  /* TODO: Fill this in. One line of code. */
}

void printStack(Stack* stack)
{
  /* TODO: Fill this in. One line of code. */
}

int isEmpty(Stack* stack)
{
  /* TODO: Fill this in. One line of code. */
}
